// StudentCard.jsx
// This component displays a student's profile card with name, major, year, image, and an optional bio.
// It uses props to receive student data and React's useState hook to control bio visibility.

import React from "react";


function StudentCard(props) {
  // Destructuring props to extract values passed from the parent component (App or Assignment component)
  const {name, major, year, bio, imageUrl} = props;

  // useState hook is used here to manage local state within the component
  // showBio is a boolean that determines if the bio text should be shown
  // setShowBio is the function we use to update this value
  const [showBio, setShowBio] = React.useState(false);

  // This function toggles the bio's visibility on button click
  const toggleBio = () => {
    setShowBio(!showBio); // Flip the boolean value (true <-> false)
  };

  // JSX structure returned to render the UI of the student card
  return (
    <div
      style={{
        maxWidth: '350px',
        padding: '20px',
        border: '1px solid #ccc',
        color: '#333333',
        borderRadius: '12px',
        fontFamily: 'Arial, sans-serif',
        textAlign: 'center',
        margin: '20px auto',
        backgroundColor: '#f9f9f9',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
      }}
    >
      {/* Student profile image */}
      <img
        src={imageUrl}
        alt={name + "'s profile"}
        style={{
          width: '100px',
          height: '100px',
          borderRadius: '50%',
          objectFit: 'cover',
          marginBottom: '12px',
        }}
      />

      {/* Student name */}
      <h2 style={{margin: '0', fontSize: '22px'}}>{name}</h2>

      {/* Major and academic year */}
      <p style={{margin: '4px 0', fontSize: '16px'}}>
        {major} – {year}
      </p>

      {/* Button that toggles the visibility of the bio section */}
      <button
        onClick={toggleBio}
        style={{
          marginTop: '12px',
          padding: '8px 16px',
          fontSize: '14px',
          borderRadius: '6px',
          border: 'none',
          cursor: 'pointer',
          backgroundColor: '#007BFF',
          color: 'white',
        }}
      >
        {/* The button label changes based on the state */}
        {showBio ? 'Hide Bio' : 'Show Bio'}
      </button>

      {/* Conditionally render the bio only if showBio is true */}
      {showBio && (
        <p style={{marginTop: '16px', fontSize: '14px'}}>{bio}</p>
      )}
    </div>
  );
}

export default StudentCard;
