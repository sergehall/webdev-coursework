import Assignment10A from "./components/Assignment10A.jsx";

function App() {
  return (
    <main>
      <Assignment10A />
    </main>
  );
}


export default App;