import AssignmentHeader from "./AssignmentHeader.jsx";

function AssignmentTemplate({title, description, children}) {
  return (
    <div>
      <div className="assignment-header">
        <AssignmentHeader title={title} description={description} />
      </div>
      <div className="assignment-section">
        {children}
      </div>
    </div>
  );
}
export default AssignmentTemplate;