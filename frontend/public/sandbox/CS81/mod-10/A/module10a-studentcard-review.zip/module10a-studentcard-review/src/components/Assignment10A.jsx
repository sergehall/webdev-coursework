import AssignmentTemplate from "./AssignmentTemplate.jsx";
import StudentCard from "./StudentCard.jsx";
import {studentData} from "../data/studentData.js";

function Assignment10A() {
  return (
    <AssignmentTemplate
      title="Module 10 Assignment 10A: Code Review - StudentCard Component"
      description="A React code review focusing on props, state, and component structure using the StudentCard component."
    >
      <StudentCard {...studentData} />
    </AssignmentTemplate>
  );
}

export default Assignment10A;
