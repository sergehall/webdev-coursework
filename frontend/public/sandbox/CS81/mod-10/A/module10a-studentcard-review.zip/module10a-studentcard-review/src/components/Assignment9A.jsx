import UserList from './UserList';
import AssignmentHeader from "./AssignmentHeader.jsx";

function Assignment9A() {
  return (
    <div>
      <div className="assignment-header">
        <AssignmentHeader
          title="Module 9 – Assignment 9A: Build Your First React Component"
          description="This assignment demonstrates how to create clean, reusable components with props, layout, and modular design using React."
        />
      </div>
      <div className="assignment-section">
        <UserList/>
      </div>
    </div>
  );
}

export default Assignment9A;
