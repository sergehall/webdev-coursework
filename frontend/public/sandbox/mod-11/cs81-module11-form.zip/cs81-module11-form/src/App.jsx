import { Routes, Route, NavLink } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Contact from './pages/Contact.jsx';
import ContactFormPage from './pages/ContactFormPage.jsx';
import Footer from './components/Footer.jsx';

function App() {
  return (
    <div
      className="App"
      style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}
    >
      <nav
        style={{
          padding: '1rem 2rem',
          background: 'linear-gradient(90deg, #3a3f87, #6a73d9, #a08eff)',
          borderBottom: '1px solid #444',
          color: 'white',
        }}
      >
        <NavLink to="/" end style={linkStyle}>
          Home
        </NavLink>
        <NavLink to="/contact-form" style={linkStyle}>
          Contact Form
        </NavLink>
        <NavLink to="/contact" style={linkStyle}>
          Contact Me
        </NavLink>
      </nav>

      <div style={{ flex: 1, padding: '2rem' }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/contact-form" element={<ContactFormPage />} />
        </Routes>
      </div>

      <Footer />
    </div>
  );
}

const linkStyle = ({ isActive }) => ({
  marginRight: '1rem',
  textDecoration: 'none',
  fontWeight: isActive ? 'bold' : 'normal',
  color: 'white',
});

export default App;
