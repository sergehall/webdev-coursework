import React, { useEffect, useState, useRef } from 'react';

function Footer() {
  const [isVisible, setIsVisible] = useState(false);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const directionUp = scrollY < lastScrollY.current;
      const windowHeight = window.innerHeight;
      const docHeight = document.documentElement.scrollHeight;

      const isAtBottom = scrollY + windowHeight >= docHeight - 1;

      if (directionUp && isAtBottom) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }

      lastScrollY.current = scrollY;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <footer
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        width: '100%',
        padding: '1.5rem 2rem',
        fontSize: '0.95rem',
        background: 'linear-gradient(to right, #f4f4f4, #eaeaea)',
        borderTop: '1px solid #ddd',
        textAlign: 'left',
        transform: isVisible ? 'translateY(0%)' : 'translateY(100%)',
        transition: 'transform 0.35s ease-in-out',
        zIndex: 100,
        color: '#333',
        boxShadow: '0 -2px 12px rgba(0,0,0,0.05)',
      }}
    >
      <p>
        <strong style={{ color: '#111' }}>Student:</strong>{' '}
        <a
          href="https://github.com/SergeHall"
          target="_blank"
          rel="noreferrer"
          style={{ color: '#4f46e5', textDecoration: 'none' }}
        >
          Siarhei Hancharou
        </a>
      </p>
      <p>
        <strong style={{ color: '#111' }}>Course:</strong>{' '}
        <span style={{ color: '#666' }}>CS 81 – JavaScript Programming</span>
      </p>
      <p>
        <strong style={{ color: '#111' }}>Instructor:</strong>{' '}
        <span style={{ color: '#444' }}>Vicky Tanya Seno – </span>
        <a
          href="mailto:seno_vicky@smc.edu"
          style={{ color: '#4f46e5', textDecoration: 'none' }}
        >
          seno_vicky@smc.edu
        </a>
      </p>
      <p>
        <strong style={{ color: '#111' }}>Institution:</strong>{' '}
        <span style={{ color: '#666' }}>
          Santa Monica College • Summer 2025
        </span>
      </p>
    </footer>
  );
}

export default Footer;
