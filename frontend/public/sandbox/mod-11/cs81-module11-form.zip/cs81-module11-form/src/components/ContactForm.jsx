import React, { useState } from 'react';

function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const [submittedData, setSubmittedData] = useState(null);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.includes('@')) newErrors.email = 'Invalid email';
    if (!formData.message.trim()) newErrors.message = 'Message is required';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length === 0) {
      setSubmittedData(formData);
      setFormData({ name: '', email: '', message: '' });
      setErrors({});
    } else {
      setErrors(validationErrors);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        background: '#f5f5f5',
        padding: '2rem',
        borderRadius: '12px',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
        maxWidth: '500px',
        margin: '0 auto',
        color: '#000',
      }}
    >
      <h2 style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
        Contact Us
      </h2>

      <label>
        Name:
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          style={{
            display: 'block',
            width: '100%',
            marginTop: '0.2rem',
            marginBottom: '1rem',
            padding: '0.5rem',
            borderRadius: '4px',
            border: '1px solid #ccc',
            backgroundColor: '#fff',
            color: '#000',
          }}
        />
        {errors.name && <p style={{ color: '#ff3333' }}>{errors.name}</p>}
      </label>

      <label>
        Email:
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          style={{
            display: 'block',
            width: '100%',
            marginTop: '0.2rem',
            marginBottom: '1rem',
            padding: '0.5rem',
            borderRadius: '4px',
            border: '1px solid #ccc',
            backgroundColor: '#fff',
            color: '#000',
          }}
        />
        {errors.email && <p style={{ color: '#ff3333' }}>{errors.email}</p>}
      </label>

      <label>
        Message:
        <textarea
          name="message"
          rows="4"
          value={formData.message}
          onChange={handleChange}
          style={{
            display: 'block',
            width: '100%',
            marginTop: '0.2rem',
            marginBottom: '1rem',
            padding: '0.5rem',
            borderRadius: '4px',
            border: '1px solid #ccc',
            backgroundColor: '#fff',
            color: '#000',
          }}
        />
        {errors.message && <p style={{ color: '#ff3333' }}>{errors.message}</p>}
      </label>

      <button
        type="submit"
        style={{
          backgroundColor: '#333',
          color: '#fff',
          padding: '0.6rem 1.2rem',
          border: 'none',
          borderRadius: '6px',
          cursor: 'pointer',
        }}
      >
        Submit
      </button>

      {submittedData && (
        <div style={{ marginTop: '1.5rem' }}>
          <h3>Submitted Data:</h3>
          <pre>{JSON.stringify(submittedData, null, 2)}</pre>
        </div>
      )}
    </form>
  );
}

export default ContactForm;
