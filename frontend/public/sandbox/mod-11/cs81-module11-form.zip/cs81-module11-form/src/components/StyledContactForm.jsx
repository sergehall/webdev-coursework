import React, { useState } from 'react';
import confetti from 'canvas-confetti';

function StyledContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [submittedData, setSubmittedData] = useState(null);
  const [errors, setErrors] = useState({});
  const [isHovered, setIsHovered] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.includes('@')) newErrors.email = 'Invalid email';
    if (!formData.message.trim()) newErrors.message = 'Message is required';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length === 0) {
      setSubmittedData(formData);
      setFormData({ name: '', email: '', message: '' });
      setErrors({});
      triggerConfetti(); // 🎊 запуск конфетти
    } else {
      setErrors(validationErrors);
    }
  };

  //  Confetti function
  const triggerConfetti = () => {
    confetti({
      particleCount: 150,
      spread: 100,
      origin: { y: 0.6 },
    });
  };

  return (
    <div
      style={{
        maxWidth: '550px',
        margin: '0 auto',
        padding: '2rem',
        background: 'linear-gradient(135deg, #eef2ff, #e0ccff)',
        borderRadius: '20px',
        boxShadow: '0 12px 24px rgba(0, 0, 0, 0.15)',
        color: '#000',
        fontFamily: 'sans-serif',
      }}
    >
      <h2 style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
        Stylish Contact Form
      </h2>

      <form onSubmit={handleSubmit}>
        {['name', 'email', 'message'].map((field) => (
          <label
            key={field}
            style={{
              display: 'block',
              marginBottom: '1.2rem',
              fontWeight: 'bold',
            }}
          >
            {field.charAt(0).toUpperCase() + field.slice(1)}:
            {field !== 'message' ? (
              <input
                type={field === 'email' ? 'email' : 'text'}
                name={field}
                placeholder={
                  field === 'name'
                    ? 'Your name'
                    : field === 'email'
                      ? 'your-email@example.com'
                      : ''
                }
                value={formData[field]}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '0.6rem',
                  marginTop: '0.3rem',
                  border: '2px solid #bbb',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                  color: '#000',
                  fontSize: '1rem',
                }}
              />
            ) : (
              <textarea
                name="message"
                rows="5"
                placeholder="Type your message here..."
                value={formData.message}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '0.6rem',
                  marginTop: '0.3rem',
                  border: '2px solid #bbb',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                  color: '#000',
                  fontSize: '1rem',
                }}
              />
            )}
            {errors[field] && (
              <p
                style={{
                  color: '#e63946',
                  fontSize: '0.9rem',
                  marginTop: '0.3rem',
                }}
              >
                {errors[field]}
              </p>
            )}
          </label>
        ))}

        <button
          type="submit"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          style={{
            width: '100%',
            padding: '0.8rem',
            background: 'linear-gradient(to right, #7c3aed, #6d28d9)',
            color: '#fff',
            border: 'none',
            borderRadius: '10px',
            fontSize: '1rem',
            fontWeight: 'bold',
            cursor: 'pointer',
            transition: 'transform 0.2s ease, box-shadow 0.2s ease',
            transform: isHovered ? 'scale(1.025)' : 'scale(1)',
            boxShadow: isHovered
              ? '0 8px 20px rgba(0, 0, 0, 0.25)'
              : '0 4px 10px rgba(0, 0, 0, 0.1)',
          }}
        >
          Send Message
        </button>
      </form>

      {submittedData && (
        <div
          style={{
            marginTop: '2rem',
            backgroundColor: '#fff',
            padding: '1rem',
            borderRadius: '12px',
            boxShadow: 'inset 0 0 8px rgba(0,0,0,0.05)',
            color: '#000',
          }}
        >
          <h3>Submitted Data:</h3>
          <pre style={{ whiteSpace: 'pre-wrap' }}>
            {JSON.stringify(submittedData, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}

export default StyledContactForm;
