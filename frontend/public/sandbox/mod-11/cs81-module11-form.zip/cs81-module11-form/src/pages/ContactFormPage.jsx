import React, { useState } from 'react';
import ContactForm from '../components/ContactForm.jsx';
import StyledContactForm from '../components/StyledContactForm.jsx';

function ContactFormPage() {
  const [formType, setFormType] = useState(null); // null, 'plain' or 'styled'

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '2rem',
        flexDirection: 'column',
        gap: '1.2rem',
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(255, 255, 255, 0.85)',
          borderRadius: '16px',
          padding: '2rem',
          maxWidth: '600px',
          width: '100%',
          boxShadow: '0 12px 28px rgba(0, 0, 0, 0.15)',
          fontFamily: 'sans-serif',
          textAlign: 'left',
          color: '#1c1c2e',
        }}
      >
        <h2 style={{ textAlign: 'center', marginBottom: '1rem' }}>
          Contact Form
        </h2>
        <p
          style={{ textAlign: 'center', color: '#666', marginBottom: '1.5rem' }}
        >
          Select which version you'd like to use:
        </p>

        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            marginBottom: '2rem',
          }}
        >
          <button
            onClick={() => setFormType('plain')}
            style={{
              marginRight: '1rem',
              padding: '0.6rem 1.2rem',
              background:
                formType === 'plain'
                  ? 'linear-gradient(90deg, #4f46e5, #6d28d9)'
                  : '#e0e0e0',
              color: formType === 'plain' ? '#fff' : '#333',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold',
              transition: 'all 0.3s ease',
              boxShadow:
                formType === 'plain'
                  ? '0 4px 12px rgba(79,70,229,0.4)'
                  : 'none',
            }}
            onMouseEnter={(e) => {
              if (formType !== 'plain') {
                e.target.style.background = '#d4d4d4';
              }
            }}
            onMouseLeave={(e) => {
              if (formType !== 'plain') {
                e.target.style.background = '#e0e0e0';
              }
            }}
          >
            Plain Form
          </button>

          <button
            onClick={() => setFormType('styled')}
            style={{
              padding: '0.6rem 1.2rem',
              background:
                formType === 'styled'
                  ? 'linear-gradient(90deg, #4f46e5, #6d28d9)'
                  : '#e0e0e0',
              color: formType === 'styled' ? '#fff' : '#333',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold',
              transition: 'all 0.3s ease',
              boxShadow:
                formType === 'styled'
                  ? '0 4px 12px rgba(79,70,229,0.4)'
                  : 'none',
            }}
            onMouseEnter={(e) => {
              if (formType !== 'styled') {
                e.target.style.background = '#d4d4d4';
              }
            }}
            onMouseLeave={(e) => {
              if (formType !== 'styled') {
                e.target.style.background = '#e0e0e0';
              }
            }}
          >
            Styled Form
          </button>
        </div>

        {formType === 'plain' && <ContactForm />}
        {formType === 'styled' && <StyledContactForm />}
      </div>
    </div>
  );
}

export default ContactFormPage;
