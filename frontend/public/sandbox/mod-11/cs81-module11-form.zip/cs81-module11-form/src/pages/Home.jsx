import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        minHeight: '100vh',
        padding: '2rem',
        fontFamily: 'sans-serif',
        lineHeight: '1.6',
        color: '#1c1c2e',
      }}
    >
      <div
        style={{
          maxWidth: '900px',
          width: '100%',
        }}
      >
        {/* Centered title */}
        <h1 style={{ textAlign: 'center', color: '#1a1a33' }}>
          Computer Science 81 <br />
          JavaScript Programming <br />
          <span style={{ fontSize: '1.2rem', color: '#444' }}>
            Summer 2025
            <br />
          </span>
        </h1>

        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            marginTop: '2rem',
          }}
        >
          {/* Info content */}
          <div
            style={{
              background: 'linear-gradient(135deg, #eef2ff, #e0ccff)',
              borderRadius: '16px',
              padding: '2rem',
              maxWidth: '600px',
              width: '100%',
              boxShadow: '0 12px 28px rgba(0, 0, 0, 0.1)',
              textAlign: 'center',
            }}
          >
            <h2 style={{ color: '#1a1a33', marginBottom: '1rem' }}>
              Module 11 Assignment 11A
            </h2>
            <p style={{ fontSize: '1.1rem', color: '#333' }}>
              <strong>React Contact Form</strong> — a hands-on task focused on
              building interactive forms using functional components and state
              management in React.
            </p>
            <p
              style={{ marginTop: '1rem', fontSize: '0.95rem', color: '#555' }}
            >
              Practice creating input fields, validating user data, handling
              form submissions, and dynamically displaying submitted content —
              all in real-time.
            </p>
            <p
              style={{
                marginTop: '1rem',
                fontSize: '0.9rem',
                color: '#6b21a8',
              }}
            >
              Experience the power of React — from simple inputs to rich user
              interaction!
            </p>
            <p
              style={{
                marginTop: '1.5rem',
                fontSize: '1rem',
                color: '#1c1c2e',
                fontWeight: 'bold',
              }}
            >
              Please navigate to{' '}
              <Link
                to="/contact-form"
                style={{
                  color: '#4f46e5',
                  textDecoration: 'none',
                  fontWeight: 'bold',
                }}
                onMouseEnter={(e) =>
                  (e.target.style.textDecoration = 'underline')
                }
                onMouseLeave={(e) => (e.target.style.textDecoration = 'none')}
              >
                Contact Form
              </Link>{' '}
              in the menu above to explore the assignment in action.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
