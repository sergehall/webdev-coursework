import React from 'react';

function Contact() {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '2rem',
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(255, 255, 255, 0.8)',
          borderRadius: '16px',
          padding: '2rem',
          maxWidth: '500px',
          width: '100%',
          boxShadow: '0 12px 28px rgba(0, 0, 0, 0.15)',
          fontFamily: 'sans-serif',
          textAlign: 'left',
          color: '#1c1c2e',
        }}
      >
        <h2 style={{ marginTop: 0, marginBottom: '1rem' }}>Contact Me</h2>

        <p style={{ marginBottom: '1rem' }}>
          For questions, collaboration, or feedback:
        </p>

        <p style={{ marginBottom: '1.5rem' }}>
          <strong>GitHub:</strong>{' '}
          <a
            href="https://github.com/SergeHall"
            target="_blank"
            rel="noreferrer"
            style={{
              color: '#1a4fff',
              textDecoration: 'none',
              fontWeight: 'bold',
            }}
          >
            github.com/SergeHall
          </a>
        </p>

        <p style={{ fontSize: '0.9rem', color: '#555' }}>
          Created for CS 81 – JavaScript Programming, Summer 2025
        </p>
      </div>
    </div>
  );
}

export default Contact;
