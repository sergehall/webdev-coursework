import AssignmentTemplate from "../components/AssignmentTemplate.jsx";
import DynamicProfileSearch from "../components/DynamicProfileSearch.jsx";

function Assignment10B() {
  return (
    <AssignmentTemplate
      title="Module 10 Assignment 10B: Dynamic Profile"
      description={
        <>
          <p>
            Create a dynamic <code>Profile</code> component using React. Practice working
            with <code>props</code> and <code>useState</code> to display personalized content and toggle details
            interactively.
          </p>
          <h4>Learning Objectives:</h4>
          <ul>
            <li>Pass data into components using <code>props</code></li>
            <li>Manage component state with <code>useState</code></li>
            <li>Render dynamic content using JSX</li>
            <li>Add interactivity with event handlers</li>
            <li>Write clean, maintainable React code</li>
          </ul>
          <p>
            <code>Props</code> allow data to flow from parent to child components. <code>State</code> manages internal,
            dynamic behavior like toggling content.
          </p>
          <p>
            <strong>Tip:</strong> To test the search feature, use one of the following names:
            <em> Serge Hall, Ravi Patel, Lina Gomez, Marco Rossi</em>.
          </p>
        </>
      }
    >
      <DynamicProfileSearch />
    </AssignmentTemplate>
  );
}

export default Assignment10B;
