const frontendProfiles = [
  {
    id: 1,
    name: 'Serge Hall',
    bio: 'Full-stack developer passionate about creating user-friendly applications.',
    profileImage: 'https://avatars.githubusercontent.com/u/60080971?v=4',
    email: 'emily.tran@example.com',
    github: 'https://github.com/emilytran',
  },
  {
    id: 2,
    name: 'Ravi Patel',
    bio: 'Frontend engineer specializing in component libraries and state management with React and Redux.',
    profileImage: 'https://randomuser.me/api/portraits/men/22.jpg',
    email: 'ravi.patel@example.com',
    github: 'https://github.com/rpateldev',
  },
  {
    id: 3,
    name: 'Lina Gomez',
    bio: 'Creative technologist using Vite and React to build modern, scalable web interfaces.',
    profileImage: 'https://randomuser.me/api/portraits/women/68.jpg',
    email: 'lina.gomez@example.com',
    github: 'https://github.com/linagomez',
  },
  {
    id: 4,
    name: 'Marco Rossi',
    bio: 'JavaScript enthusiast and educator building interactive UIs with React Hooks and Vite.',
    profileImage: 'https://randomuser.me/api/portraits/men/65.jpg',
    email: 'marco.rossi@example.com',
    github: 'https://github.com/marcorossi',
  },

];

export default frontendProfiles;
