import { useState } from "react";
import Profile from "./Profile.jsx";
import dynamicProfile from "../data/dynamicProfile.js";

function DynamicProfileSearch() {
  const [searchName, setSearchName] = useState("");
  const [result, setResult] = useState(null);

  const handleSearch = () => {
    const name = searchName.trim().toLowerCase();
    if (name === "") {
      setResult(null);
      return;
    }

    const found = dynamicProfile.find(profile =>
      profile.name.toLowerCase().includes(name)
    );
    setResult(found || false); // false = not found
  };

  return (
    <div className="dynamicProfile-search">
      <div className="dynamicProfile-inputWrapper">
        <input
          type="text"
          placeholder="Enter a name (e.g. Serge Hall)"
          value={searchName}
          onChange={(e) => setSearchName(e.target.value)}
          className="dynamicProfile-input"
        />
        <button className="btn-soft" onClick={handleSearch}>
          Search
        </button>
      </div>

      {result && typeof result === "object" ? (
        <Profile {...result} />
      ) : result === false ? (
        <p>No profile with that name was found.</p>
      ) : null}
    </div>
  );
}

export default DynamicProfileSearch;
