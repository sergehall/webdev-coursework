import AssignmentTemplate from "../components/AssignmentTemplate.jsx";
import UserList from '../components/UserList.jsx';

function Assignment9B() {
  return (
    <AssignmentTemplate
      title="Module 9 – Assignment 9B: Custom Profile Component"
      description="This project displays user profile cards using both inline CSS and class-based styling. The inline version is used to meet assignment requirements, while the class-based version offers enhanced design flexibility."
    >
      <UserList/>
    </AssignmentTemplate>
  );
}

export default Assignment9B;
