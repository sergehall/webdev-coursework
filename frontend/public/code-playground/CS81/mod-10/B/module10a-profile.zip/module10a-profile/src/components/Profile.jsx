import { useState } from 'react';
import { FaEnvelope, FaGithub } from 'react-icons/fa';

function Profile({ name, occupation, funFact, profileImage, bio, email, github }) {
  const [showDetail, setShowDetail] = useState(false);

  const toggleDetail = () => setShowDetail(!showDetail);

  return (
    <div className="dynamicProfile-card">
      {profileImage && <img src={profileImage} alt={`${name}'s avatar`} />}
      <h2 className="dynamicProfile-name">{name}</h2>
      <p><strong>Occupation:</strong> {occupation}</p>
      <p><strong>Fun Fact:</strong> {funFact}</p>

      <button className="btn-soft" onClick={toggleDetail}>
        {showDetail ? 'Hide Bio ▲' : 'Show Bio ▼'}
      </button>

      {showDetail && (
        <div className="dynamicProfile-bio">
          <p>{bio || `${name} is known for pushing creative boundaries and bringing innovation to the ${occupation.toLowerCase()} world.`}</p>

          {email && (
            <p>
              <strong>
                <FaEnvelope className="dynamicProfile-icon" />
                Email:
              </strong>{' '}
              <a href={`mailto:${email}`} className="dynamicProfile-link">
                {email}
              </a>
            </p>
          )}

          {github && (
            <p>
              <strong>
                <FaGithub className="dynamicProfile-icon" />
                GitHub:
              </strong>{' '}
              <a href={github} target="_blank" rel="noopener noreferrer" className="dynamicProfile-link">
                {github}
              </a>
            </p>
          )}

        </div>
      )}
    </div>
  );
}

export default Profile;
