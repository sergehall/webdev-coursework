import Assignment10B from "./Assignmens/Assignment10B.jsx";

function App() {
  return (
    <main>
      <Assignment10B />
    </main>
  );
}


export default App;